package com.UST.hib;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibApplicationTests {

	@Test
	void contextLoads() {
	}

}
