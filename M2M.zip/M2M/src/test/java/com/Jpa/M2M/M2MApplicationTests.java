package com.Jpa.M2M;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class M2MApplicationTests {

	@Test
	void contextLoads() {
	}

}
