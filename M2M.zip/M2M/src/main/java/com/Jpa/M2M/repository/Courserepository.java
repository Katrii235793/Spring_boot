/**
 * 
 */
package com.Jpa.M2M.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.Jpa.M2M.entity.Courses;

/**
 * @author ustjavafsdb109
 *
 */
public interface Courserepository extends  JpaRepository <Courses,Long>{

}
